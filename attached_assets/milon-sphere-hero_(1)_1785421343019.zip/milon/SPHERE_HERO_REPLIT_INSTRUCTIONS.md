# Sphere Hero — Replit integration

Two new files do all the work; you touch `app.tsx` in three small spots. No logic is duplicated — the spheres read the same `healthMap` / `pillarHealths` / `avgHealth` you already compute.

## New files (already in this zip)
- `src/components/sphere-hero.tsx` — the morphing 3-level sphere UI + synthesized metallic click.
- `src/components/sphere-hero-adapter.ts` — maps your existing health data into the sphere's props.

## Step 1 — Add the imports
Near the other component imports at the top of `src/routes/app.tsx` (there's currently a line `import { TreeHero } from "@/components/tree-hero";`), add:

```ts
import { SphereHero } from "@/components/sphere-hero";
import { buildSpherePillars } from "@/components/sphere-hero-adapter";
```

You can delete the `TreeHero` import once Step 3 is done.

## Step 2 — Build the pillar data (once, near where `healthMap` / `pillarHealths` / `avgHealth` are in scope)
Somewhere after `pillarHealths` is defined and before the JSX return, add:

```ts
const spherePillars = buildSpherePillars({
  overallHealth: avgHealth,
  pillarHealths,
  healthMap,
  ratioMeta: RATIO_META,
  // Optional: pass deltas if you track period-over-period change.
  // overallDelta: ..., pillarDeltas: { profit: 8, cash: 10, ... },
});
```

If `avgHealth`, `healthMap`, `pillarHealths`, or `RATIO_META` are defined inside a different scope (e.g. a `useMemo`), lift this `buildSpherePillars(...)` call into that same scope so all four are visible.

## Step 3 — Replace the TreeHero block
Find this in the JSX (around line 2160):

```tsx
<TreeHero
  ratioLookup={ratioLookup}
  extras={{ avgHealth, businessName: actingClientName ?? undefined }}
  onSelect={({ tab, section }) => {
    setActiveTab(tab);
    if (section) setHighlightId(section);
  }}
/>
```

Replace it with:

```tsx
<SphereHero
  overallHealth={avgHealth}
  pillars={spherePillars}
  topPriority={{
    title: "Improve cash conversion cycle",
    description: "Focus on reducing debtor days to improve cash flow.",
  }}
  onTopPriority={() => {
    setActiveTab("cash");        // jump to the relevant tab
  }}
/>
```

The `topPriority` can be static for now, or wired to your worst-scoring pillar/ratio later. `onTopPriority` is optional.

## Step 4 — Sanity check
- `pnpm dev` (or the Replit run button).
- Level 1: big gold sphere + 4-stat row. Tap it → Level 2 (sphere shrinks, 2×2 pillar grid morphs in). Tap a pillar → Level 3 (pillar sphere + driver rows with bars). Back arrows and tapping the shrunk sphere both reverse the morph.
- You should hear a short metallic "klink" on the first tap (browsers block audio until the first user gesture — the first tap is the gesture, so it plays from then on).

## Notes
- **No audio file needed** — the click is synthesized with the Web Audio API. If a browser blocks audio entirely, the UI still works silently.
- **Colors are tier-driven**: healthy ≥65 green, watch 40–64 amber, critical <40 red — matching `scoreTier` in `@/lib/ratios`. The overall/main sphere stays gold when healthy/watch (per your mockups) and only turns red if critical.
- **No-data safe**: any ratio that is `NaN` (missing input) shows "—" in neutral grey rather than a misleading 0, consistent with the rest of the app.
- **Driver grouping** lives in `PILLAR_DRIVER_KEYS` in the adapter — edit there if you want a pillar to show different underlying ratios.
- **Tune the sound**: the partial frequencies/decays are in `playKlink()` in `sphere-hero.tsx`. Lower frequencies = duller/heavier; shorter decay = tighter click.
- `tree-hero.tsx` can be deleted once you're happy, or kept unused. Nothing else imports it after Step 3 except its own file.
