# MILŌN — Ask AI

Wires the "Ask anything about your numbers…" box to Gemini Flash, sending only
anonymised ratio context.

## What Gemini receives

| Sent | Never sent |
|---|---|
| Industry (as selected at onboarding) | Company name, reg number, VAT number |
| Revenue **band** (`5m_15m`) | Actual revenue or any rand amount |
| Business age band, entity type | Incorporation date, directors |
| B2B/B2C, inventory y/n, VAT y/n | Bank details, transactions |
| Financial-year month (`8 of 12`) | Dates |
| Pillar scores + ratio values, bands, trends | Customer or supplier names |
| Industry median and percentile per ratio | Account balances |
| Facility **types** (`overdraft`) | Limits, balances, lender names |
| Top-customer concentration band | Which customer |
| Playbook keys already shown + status | Notes, comments |

## Disclosure tiers

The classifier picks the cheapest tier that can answer the question.

| Tier | When | Roughly |
|---|---|---|
| `none` | "What is a current ratio?" | 0 tokens of company data |
| `summary` | No clear pillar signal | ~120 tokens |
| `focused` | Question maps to one pillar | ~350 tokens |
| `full` | "Where should I start?" | ~900 tokens, capped at 14 ratios |

Definitional answers cache across all tenants for 30 days, so the second person
to ask what a current ratio is costs nothing.

## Setup

**1. Database**

Run `sql/ask_ai_setup.sql`. Adjust the three `v_ask_ai_*` views to match your
table and column names — that's the only place your schema is referenced.

**2. Secrets**

```bash
supabase secrets set GEMINI_API_KEY=...
supabase secrets set GEMINI_MODEL=gemini-2.0-flash
supabase secrets set ALLOWED_ORIGINS=https://app.milon.co.za,http://localhost:5173
supabase secrets set ASK_AI_RATE_LIMIT=30
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are injected
automatically.

**3. Deploy**

```bash
supabase functions deploy ask-ai
```

**4. Front end**

```html
<link rel="stylesheet" href="/ask-ai.css">
<div id="ask-ai"></div>

<script type="module">
  import { mountAskAi } from '/ask-ai.js';
  mountAskAi(document.getElementById('ask-ai'), {
    endpoint: 'https://YOUR-PROJECT.supabase.co/functions/v1/ask-ai',
    getToken: async () => (await supabase.auth.getSession()).data.session?.access_token,
  });
</script>
```

Drop it where the current input sits and delete the old markup — the widget
renders its own input bar.

## Security notes

- **Company is resolved from the JWT**, never from the request body. A caller
  can't ask about someone else's numbers by changing an ID.
- **Service-role key stays server-side.** It's only in the edge function.
- **`ask_ai_log` stores no question or answer text** — only length, which
  redaction rules fired, token counts and latency. Enough to tune the
  classifier, not enough to reconstruct anyone's question.
- **Prompt injection**: the question is fenced in an untrusted block and the
  system prompt tells the model to treat it as data. Angle brackets, braces and
  fake role prefixes are stripped before it gets there.
- **The sanitiser is defence in depth, not a guarantee.** If a client types a
  company name it doesn't recognise as one, that name reaches Gemini. Word your
  privacy terms accordingly — say identifying details are stripped on a
  best-effort basis and that clients shouldn't type names into the box, rather
  than claiming full anonymity.
- Check Google's data-use terms for the API tier you're on before you make any
  retention promise to clients. Paid and free tiers differ.

## Tuning

After a week, look at where the classifier is landing:

```sql
select disclosure, focus_pillar, count(*),
       round(avg(prompt_tokens)) as avg_prompt_tokens,
       round(avg(latency_ms))    as avg_ms
from public.ask_ai_log
where created_at > now() - interval '7 days'
group by 1, 2
order by 3 desc;
```

If `summary` is large, the pillar term lists in `classifier.ts` are missing
vocabulary your clients actually use. If `full` is large, the broad-question
patterns are over-firing and you're paying for it.

## Files

```
supabase/functions/ask-ai/
  index.ts             auth, rate limit, cache, orchestration
  classifier.ts        picks the disclosure tier — no LLM call
  context-builder.ts   the only file that touches the database
  prompt.ts            system prompt + compact serialisation
  sanitizer.ts         strips identifiers from the question
  gemini.ts            API client
  types.ts             disclosure surface, defined once
sql/ask_ai_setup.sql   views, cache, log, rate limit
public/ask-ai.js       widget
public/ask-ai.css      styles
```
