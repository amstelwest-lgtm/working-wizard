/**
 * MILŌN — Ask AI widget
 *
 * Usage:
 *   <div id="ask-ai"></div>
 *   <script type="module">
 *     import { mountAskAi } from './ask-ai.js';
 *     mountAskAi(document.getElementById('ask-ai'), {
 *       endpoint: 'https://YOUR-PROJECT.supabase.co/functions/v1/ask-ai',
 *       getToken: async () => (await supabase.auth.getSession()).data.session?.access_token,
 *     });
 *   </script>
 */

const MAX_CHARS = 600;

const SUGGESTIONS = [
  'Why is my cash score only 63?',
  'What is a cash conversion cycle?',
  'Where should I focus first?',
];

export function mountAskAi(root, { endpoint, getToken, suggestions = SUGGESTIONS }) {
  if (!root) throw new Error('mountAskAi: no root element');
  if (!endpoint) throw new Error('mountAskAi: no endpoint');

  root.innerHTML = `
    <section class="askai" aria-labelledby="askai-label">
      <h2 id="askai-label" class="askai__sr">Ask AI about your numbers</h2>

      <div class="askai__thread" id="askai-thread" role="log" aria-live="polite" aria-atomic="false"></div>

      <form class="askai__bar" id="askai-form" novalidate>
        <span class="askai__spark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
               stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"/>
            <path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z"/>
          </svg>
        </span>
        <input
          class="askai__input"
          id="askai-input"
          type="text"
          name="question"
          maxlength="${MAX_CHARS}"
          autocomplete="off"
          placeholder="Ask anything about your numbers…"
          aria-describedby="askai-hint"
        />
        <button class="askai__send" type="submit" aria-label="Send question">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
               stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M5 12h13M13 6l6 6-6 6"/>
          </svg>
        </button>
      </form>

      <p class="askai__hint" id="askai-hint">
        Your business is never named. Only anonymised ratios are shared.
      </p>

      <div class="askai__chips" id="askai-chips">
        ${suggestions.map((s) => `<button type="button" class="askai__chip">${escapeHtml(s)}</button>`).join('')}
      </div>
    </section>
  `;

  const form = root.querySelector('#askai-form');
  const input = root.querySelector('#askai-input');
  const thread = root.querySelector('#askai-thread');
  const chips = root.querySelector('#askai-chips');
  const section = root.querySelector('.askai');

  let busy = false;

  chips.addEventListener('click', (e) => {
    const chip = e.target.closest('.askai__chip');
    if (!chip || busy) return;
    input.value = chip.textContent;
    form.requestSubmit();
  });

  thread.addEventListener('click', (e) => {
    const chip = e.target.closest('.askai__followup');
    if (!chip || busy) return;
    input.value = chip.textContent;
    form.requestSubmit();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const question = input.value.trim();
    if (!question || busy) return;

    setBusy(true);
    section.classList.add('askai--active');
    chips.hidden = true;
    input.value = '';

    appendQuestion(thread, question);
    const pending = appendPending(thread);

    try {
      const token = await getToken();
      if (!token) throw new Error('signed_out');

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ question }),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        pending.replaceWith(buildError(data.error || 'Couldn\'t get an answer. Try again.'));
        return;
      }

      pending.replaceWith(buildAnswer(data.answer, data.followups || []));
    } catch (err) {
      pending.replaceWith(
        buildError(
          err.message === 'signed_out'
            ? 'Sign in again to ask a question.'
            : 'No connection. Check your network and try again.',
        ),
      );
    } finally {
      setBusy(false);
      thread.lastElementChild?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      input.focus();
    }
  });

  function setBusy(state) {
    busy = state;
    section.classList.toggle('askai--busy', state);
    input.disabled = state;
    form.querySelector('.askai__send').disabled = state;
  }

  return {
    ask(question) {
      input.value = question;
      form.requestSubmit();
    },
    destroy() {
      root.innerHTML = '';
    },
  };
}

/* ---------- rendering ---------- */

function appendQuestion(thread, text) {
  const el = document.createElement('div');
  el.className = 'askai__turn askai__turn--you';
  el.textContent = text;
  thread.append(el);
  return el;
}

function appendPending(thread) {
  const el = document.createElement('div');
  el.className = 'askai__turn askai__turn--ai askai__turn--pending';
  el.innerHTML = `
    <span class="askai__dots" aria-label="Working on it">
      <i></i><i></i><i></i>
    </span>`;
  thread.append(el);
  return el;
}

function buildAnswer(text, followups) {
  const el = document.createElement('div');
  el.className = 'askai__turn askai__turn--ai';

  const body = document.createElement('div');
  body.className = 'askai__answer';
  for (const para of String(text).split(/\n{2,}/)) {
    if (!para.trim()) continue;
    const p = document.createElement('p');
    p.textContent = para.trim();
    body.append(p);
  }
  el.append(body);

  if (followups.length) {
    const row = document.createElement('div');
    row.className = 'askai__followups';
    for (const f of followups.slice(0, 2)) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'askai__followup';
      b.textContent = f;
      row.append(b);
    }
    el.append(row);
  }
  return el;
}

function buildError(message) {
  const el = document.createElement('div');
  el.className = 'askai__turn askai__turn--error';
  el.textContent = message;
  return el;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}
