-- MILŌN — Ask AI
-- Run in the Supabase SQL editor.
--
-- The three v_ask_ai_* views are the contract between your schema and the edge
-- function. If your column names differ, change them HERE and leave the
-- TypeScript alone. Each view exposes only fields that are safe to derive an
-- anonymised payload from — no company names, no rand amounts.

-- ===========================================================================
-- 1. VIEWS  (adapt the FROM clauses to your actual tables)
-- ===========================================================================

create or replace view public.v_ask_ai_profile as
select
  c.id                            as company_id,
  c.industry,                     -- selected at onboarding
  c.annual_revenue,               -- bucketed in TS, never sent raw
  c.incorporated_on,
  c.entity_type,                  -- pty_ltd | cc | sole_prop | trust | partnership
  c.customer_model,               -- b2b | b2c | mixed
  c.carries_inventory,
  c.vat_registered,
  c.fy_start_month,               -- 1-12
  c.debt_facilities,              -- text[]: overdraft, term_loan, asset_finance...
  c.top_customer_pct              -- numeric, bucketed in TS
from public.companies c;

comment on view public.v_ask_ai_profile is
  'Ask AI disclosure surface. Adding a column here widens what can reach Gemini.';


create or replace view public.v_ask_ai_scores as
select
  s.company_id,
  s.overall_score,
  s.profit_score,
  s.assets_score,
  s.financing_score,
  s.cash_score
from public.health_scores s
where s.is_current;          -- or: distinct on (company_id) ... order by period desc


create or replace view public.v_ask_ai_ratios as
select
  r.company_id,
  r.ratio_key,                    -- stable slug, e.g. debtor_days
  r.pillar,                       -- profit | assets | financing | cash
  r.value,
  r.unit,                         -- days | % | x | ratio
  r.band,                         -- strong | healthy | watch | critical
  b.median          as industry_median,
  r.percentile,
  r.prior_value,
  d.higher_is_better
from public.ratio_results r
join public.ratio_definitions d on d.ratio_key = r.ratio_key
left join public.industry_benchmarks b
       on b.ratio_key = r.ratio_key
      and b.industry  = (select industry from public.companies where id = r.company_id)
where r.is_current;


create or replace view public.v_ask_ai_playbook_history as
select
  p.company_id,
  p.playbook_key,
  p.status                        -- dismissed | in_progress | completed
from public.playbook_assignments p
where p.status in ('dismissed', 'in_progress', 'completed')
order by p.updated_at desc;


-- ===========================================================================
-- 2. CACHE  (definitional answers, shared across all tenants)
-- ===========================================================================

create table if not exists public.ask_ai_cache (
  cache_key   text primary key,
  answer      text        not null,
  followups   text[]      not null default '{}',
  created_at  timestamptz not null default now(),
  expires_at  timestamptz not null
);

create index if not exists ask_ai_cache_expires_idx
  on public.ask_ai_cache (expires_at);

alter table public.ask_ai_cache enable row level security;
-- No policies: service role only. Clients must never read this directly.


-- ===========================================================================
-- 3. LOGGING  (shape and cost, never content)
-- ===========================================================================

create table if not exists public.ask_ai_log (
  id               bigint generated always as identity primary key,
  user_id          uuid        not null,
  company_id       uuid        not null,
  disclosure       text        not null,
  focus_pillar     text,
  question_length  int,
  redactions_fired text[]      not null default '{}',
  prompt_tokens    int,
  output_tokens    int,
  latency_ms       int,
  cached           boolean     not null default false,
  error            text,
  created_at       timestamptz not null default now()
);

comment on table public.ask_ai_log is
  'Deliberately stores no question or answer text. Do not add columns for either.';

create index if not exists ask_ai_log_user_time_idx
  on public.ask_ai_log (user_id, created_at desc);

alter table public.ask_ai_log enable row level security;
-- No policies: service role writes, you read via the dashboard.


-- ===========================================================================
-- 4. RATE LIMIT
-- ===========================================================================

create or replace function public.ask_ai_check_rate_limit(
  p_user_id uuid,
  p_limit   int default 30
) returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  recent_count int;
begin
  select count(*) into recent_count
  from public.ask_ai_log
  where user_id = p_user_id
    and created_at > now() - interval '1 hour';

  return recent_count < p_limit;
end;
$$;

revoke all on function public.ask_ai_check_rate_limit(uuid, int) from public, anon, authenticated;


-- ===========================================================================
-- 5. HOUSEKEEPING
-- ===========================================================================

-- Expired cache rows. Schedule with pg_cron if you have it enabled.
-- select cron.schedule('ask-ai-cache-sweep', '0 3 * * *',
--   $$delete from public.ask_ai_cache where expires_at < now()$$);

-- Log retention: 90 days is plenty for tuning the classifier.
-- select cron.schedule('ask-ai-log-sweep', '15 3 * * *',
--   $$delete from public.ask_ai_log where created_at < now() - interval '90 days'$$);
