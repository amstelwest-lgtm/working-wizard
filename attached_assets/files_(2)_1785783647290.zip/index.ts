// MILŌN — Ask AI
// POST /functions/v1/ask-ai
// Body: { "question": "why is my cash score low?" }
//
// Flow: auth → sanitise → classify → cache → build context → Gemini → log.

import { createClient } from "jsr:@supabase/supabase-js@2";
import { buildContext, serviceClient } from "./context-builder.ts";
import { classify } from "./classifier.ts";
import { askGemini } from "./gemini.ts";
import { buildUserTurn, SYSTEM_PROMPT } from "./prompt.ts";
import { cacheKeyFor, MAX_QUESTION_CHARS, sanitiseQuestion } from "./sanitizer.ts";
import type { AskResponse } from "./types.ts";

const ALLOWED_ORIGINS = (Deno.env.get("ALLOWED_ORIGINS") ?? "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);

const RATE_LIMIT_PER_HOUR = Number(Deno.env.get("ASK_AI_RATE_LIMIT") ?? "30");
const GEMINI_TIMEOUT_MS = 25_000;

function corsHeaders(origin: string | null): Record<string, string> {
  const allow = origin && (ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin))
    ? origin
    : ALLOWED_ORIGINS[0] ?? "";
  return {
    "Access-Control-Allow-Origin": allow,
    "Access-Control-Allow-Headers": "authorization, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}

function json(body: unknown, status: number, origin: string | null): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders(origin) },
  });
}

Deno.serve(async (req) => {
  const origin = req.headers.get("origin");

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders(origin) });
  }
  if (req.method !== "POST") {
    return json({ error: "Use POST." }, 405, origin);
  }

  // --- Auth: resolve the caller from their JWT, not from anything they send --
  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace(/^Bearer\s+/i, "");
  if (!token) return json({ error: "Sign in to ask a question." }, 401, origin);

  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } },
  );

  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) {
    return json({ error: "Your session has expired. Sign in again." }, 401, origin);
  }
  const userId = userData.user.id;

  const db = serviceClient();

  // Company comes from the membership table, never from the request body.
  const { data: membership, error: memErr } = await db
    .from("company_members")
    .select("company_id")
    .eq("user_id", userId)
    .maybeSingle<{ company_id: string }>();

  if (memErr || !membership) {
    return json({ error: "No business is linked to this account." }, 403, origin);
  }
  const companyId = membership.company_id;

  // --- Input ---------------------------------------------------------------
  let question: string;
  try {
    const body = await req.json() as { question?: unknown };
    if (typeof body.question !== "string" || !body.question.trim()) {
      return json({ error: "Type a question to get an answer." }, 400, origin);
    }
    question = body.question;
  } catch {
    return json({ error: "Couldn't read that request." }, 400, origin);
  }

  if (question.length > MAX_QUESTION_CHARS * 2) {
    return json(
      { error: `Keep it under ${MAX_QUESTION_CHARS} characters so I can answer properly.` },
      400,
      origin,
    );
  }

  const { clean, redactions } = sanitiseQuestion(question);
  if (!clean) return json({ error: "Type a question to get an answer." }, 400, origin);

  // --- Rate limit ----------------------------------------------------------
  const { data: allowed, error: rlErr } = await db.rpc("ask_ai_check_rate_limit", {
    p_user_id: userId,
    p_limit: RATE_LIMIT_PER_HOUR,
  });
  if (rlErr) console.error("rate limit check failed", rlErr.message);
  if (allowed === false) {
    return json(
      { error: "You've hit the hourly question limit. Try again shortly." },
      429,
      origin,
    );
  }

  // --- Classify ------------------------------------------------------------
  const classification = classify(clean);

  if (classification.refusal) {
    return json(
      {
        answer: classification.refusal,
        followups: [],
        disclosure: "none",
        cached: false,
      } satisfies AskResponse,
      200,
      origin,
    );
  }

  // --- Cache: definitional answers are identical for every tenant ----------
  const key = classification.cacheable ? cacheKeyFor(clean) : null;
  if (key) {
    const { data: hit } = await db
      .from("ask_ai_cache")
      .select("answer, followups")
      .eq("cache_key", key)
      .gt("expires_at", new Date().toISOString())
      .maybeSingle<{ answer: string; followups: string[] }>();

    if (hit) {
      return json(
        {
          answer: hit.answer,
          followups: hit.followups ?? [],
          disclosure: "none",
          cached: true,
        } satisfies AskResponse,
        200,
        origin,
      );
    }
  }

  // --- Context + model -----------------------------------------------------
  const started = Date.now();
  try {
    const context = await buildContext(db, companyId, classification);
    const userTurn = buildUserTurn(context, clean);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), GEMINI_TIMEOUT_MS);
    let result;
    try {
      result = await askGemini(SYSTEM_PROMPT, userTurn, controller.signal);
    } finally {
      clearTimeout(timer);
    }

    if (key) {
      await db.from("ask_ai_cache").upsert({
        cache_key: key,
        answer: result.answer,
        followups: result.followups,
        expires_at: new Date(Date.now() + 30 * 86_400_000).toISOString(),
      });
    }

    // Log shape and cost, never content. question_shape is a token count and
    // the redaction rules that fired — enough to tune the classifier, not
    // enough to reconstruct what anyone asked.
    await db.from("ask_ai_log").insert({
      user_id: userId,
      company_id: companyId,
      disclosure: classification.disclosure,
      focus_pillar: classification.focusPillar ?? null,
      question_length: clean.length,
      redactions_fired: redactions,
      prompt_tokens: result.usage?.promptTokens ?? null,
      output_tokens: result.usage?.outputTokens ?? null,
      latency_ms: Date.now() - started,
      cached: false,
    });

    return json(
      {
        answer: result.answer,
        followups: result.followups,
        disclosure: classification.disclosure,
        cached: false,
      } satisfies AskResponse,
      200,
      origin,
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("ask-ai failed", message);

    await db.from("ask_ai_log").insert({
      user_id: userId,
      company_id: companyId,
      disclosure: classification.disclosure,
      focus_pillar: classification.focusPillar ?? null,
      question_length: clean.length,
      redactions_fired: redactions,
      latency_ms: Date.now() - started,
      error: message.slice(0, 300),
      cached: false,
    }).then(() => {}, () => {});

    const timedOut = message.includes("abort");
    return json(
      {
        error: timedOut
          ? "That took too long to answer. Try asking it more narrowly."
          : "Couldn't get an answer just now. Try again in a moment.",
      },
      timedOut ? 504 : 502,
      origin,
    );
  }
});
