// MILŌN — Ask AI
// Redacts identifiers from the question the client types.
//
// Important limitation, stated plainly: this is defence in depth, not a
// guarantee. If a client types a company name we don't recognise as a company
// name, it goes through. The system prompt also instructs Gemini to ignore
// identifying details, and we don't persist raw questions in identifiable form.
// Do not market this as "your data never leaves anonymous" on the strength of
// this file alone.

import type { SanitiseResult } from "./types.ts";

interface Rule {
  name: string;
  pattern: RegExp;
  replacement: string;
}

const RULES: Rule[] = [
  // --- South African identifiers -------------------------------------------
  {
    // Company registration: 2019/123456/07
    name: "sa_company_reg",
    pattern: /\b(19|20)\d{2}\s*\/\s*\d{4,7}\s*\/\s*\d{2}\b/g,
    replacement: "[REG]",
  },
  {
    // VAT number: 10 digits starting with 4
    name: "sa_vat",
    pattern: /\b4\d{9}\b/g,
    replacement: "[VAT]",
  },
  {
    // ID number: 13 digits, YYMMDD prefix
    name: "sa_id",
    pattern: /\b\d{6}\s?\d{4}\s?\d{3}\b/g,
    replacement: "[ID]",
  },
  {
    // Bank account: 8-12 consecutive digits not already caught above
    name: "bank_account",
    pattern: /\b\d{8,12}\b/g,
    replacement: "[ACCT]",
  },

  // --- Contact details ------------------------------------------------------
  {
    name: "email",
    pattern: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
    replacement: "[EMAIL]",
  },
  {
    name: "phone",
    pattern: /(?:\+27|0)\s?\d{2}\s?\d{3}\s?\d{4}\b/g,
    replacement: "[PHONE]",
  },
  {
    name: "url",
    pattern: /\bhttps?:\/\/\S+/gi,
    replacement: "[URL]",
  },

  // --- Entity names ---------------------------------------------------------
  {
    // Capitalised words immediately preceding a legal suffix.
    // "Bosch Civils (Pty) Ltd" -> "[COMPANY]"
    name: "entity_suffix",
    pattern:
      /\b(?:[A-Z][\w&'-]*\s+){0,4}(?:\(?\s*(?:Pty|PTY|Edms|EDMS)\s*\)?\s*(?:Ltd|LTD|Bpk|BPK)|\bCC\b|\bInc\b|\bNPC\b|\bLtd\b|\bLimited\b)\.?/g,
    replacement: "[COMPANY]",
  },
  {
    // "my company Acme", "we are called Acme", "trading as Acme"
    name: "named_as",
    pattern:
      /\b(?:t\/a|trading as|trading under|called|named|company is|business is|firm is)\s+(?:[A-Z][\w&'-]*(?:\s+[A-Z][\w&'-]*){0,3})/g,
    replacement: "[COMPANY]",
  },
  {
    // "our client Woolworths", "customer Shoprite owes us"
    name: "named_counterparty",
    pattern:
      /\b(?:client|customer|supplier|debtor|creditor|vendor|landlord|lender|bank)\s+(?:called\s+)?([A-Z][\w&'-]*(?:\s+[A-Z][\w&'-]*){0,2})/g,
    replacement: "counterparty",
  },
];

/** Hard cap on question length. Stops prompt-stuffing and runaway token spend. */
export const MAX_QUESTION_CHARS = 600;

export function sanitiseQuestion(raw: string): SanitiseResult {
  let clean = raw.normalize("NFKC").trim();
  const redactions: string[] = [];

  // Collapse whitespace early so multi-line pastes can't smuggle structure.
  clean = clean.replace(/\s+/g, " ");

  if (clean.length > MAX_QUESTION_CHARS) {
    clean = clean.slice(0, MAX_QUESTION_CHARS);
    redactions.push("truncated");
  }

  for (const rule of RULES) {
    if (rule.pattern.test(clean)) {
      redactions.push(rule.name);
      clean = clean.replace(rule.pattern, rule.replacement);
    }
    // Reset lastIndex — these are /g regexes and .test() advances it.
    rule.pattern.lastIndex = 0;
  }

  // Strip characters used to fake role boundaries in the prompt.
  clean = clean.replace(/[<>{}]/g, "");
  clean = clean.replace(/\b(system|assistant|user)\s*:/gi, "");

  return { clean, redactions };
}

/**
 * Normalised form used as the cross-tenant cache key for definitional answers.
 * Lowercased, punctuation dropped, stopwords kept (they carry meaning in short
 * questions like "what is a current ratio").
 */
export function cacheKeyFor(question: string): string {
  return question
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
