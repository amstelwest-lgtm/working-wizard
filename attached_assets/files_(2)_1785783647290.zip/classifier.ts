// MILŌN — Ask AI
// Decides how much context a question actually needs, before we spend tokens.
//
// This is deliberately a local heuristic rather than an LLM call. A classifier
// round-trip would roughly double latency and cost on every message, to route
// a question set that is heavily concentrated in a few shapes. Revisit if the
// misroute rate justifies it — measure with the ask_ai_log table first.

import type { ClassificationResult, Pillar } from "./types.ts";

const PILLAR_TERMS: Record<Pillar, string[]> = {
  cash: [
    "cash", "cashflow", "cash flow", "liquidity", "runway", "debtor", "debtors",
    "receivable", "receivables", "collect", "collections", "creditor", "creditors",
    "payable", "payables", "conversion cycle", "ccc", "current ratio", "quick ratio",
    "working capital", "overdraft", "bank balance", "burn",
  ],
  profit: [
    "profit", "profitable", "margin", "margins", "gross", "net income", "ebitda",
    "overhead", "overheads", "expense", "expenses", "cost", "costs", "pricing",
    "price", "markup", "revenue", "turnover", "sales", "breakeven", "break even",
    "operating profit", "bottom line",
  ],
  assets: [
    "asset", "assets", "stock", "inventory", "fixed asset", "depreciation",
    "utilisation", "utilization", "asset turnover", "equipment", "vehicle",
    "vehicles", "capex", "return on assets", "roa", "obsolete",
  ],
  financing: [
    "debt", "loan", "loans", "gearing", "leverage", "interest", "interest cover",
    "solvency", "equity", "funding", "finance", "financing", "repay", "repayment",
    "instalment", "installment", "covenant", "borrow", "borrowing", "lender",
    "debt to equity", "capital structure",
  ],
};

/** Questions that need no company data whatsoever. */
const DEFINITIONAL_PATTERNS = [
  /^what (?:is|are|does|do)\b.*\b(?:mean|ratio|metric|score|term)\b/i,
  /^(?:what|how) (?:is|are|does) (?:a|an|the) [\w\s]+ (?:calculated|worked out|derived)/i,
  /^define\b/i,
  /^explain (?:what|the (?:concept|term|meaning))/i,
  /^how (?:do|does) (?:milon|milōn|this|the) (?:app|platform|dashboard|score|tool)\b/i,
  /^(?:what|which) (?:does|do) (?:this|the) (?:score|number|band|colour|color)\b/i,
];

/** Questions that legitimately need everything we have. */
const BROAD_PATTERNS = [
  /\b(?:overall|whole|entire|full|general|holistic)\b.*\b(?:health|picture|position|review|state|business)\b/i,
  /\bwhat(?:'s| is| are)? (?:my |our )?(?:biggest|main|top|worst|first) (?:problem|issue|risk|priority|concern|weakness)/i,
  /\bwhere (?:should|do) (?:i|we) (?:start|focus|begin)\b/i,
  /\bhow (?:is|are) (?:my|our|the) business (?:doing|performing|going)\b/i,
  /\bsummar(?:y|ise|ize)\b/i,
  /\bwhat should (?:i|we) (?:do|fix|change)\b/i,
];

/** Things we won't answer. Cheap guard against scope creep into regulated advice. */
const OUT_OF_SCOPE = [
  {
    pattern: /\b(?:should i|shall i|can i)\b.*\b(?:invest in|buy shares|crypto|bitcoin|forex)\b/i,
    message:
      "I can't give investment advice. I can help you read the ratios behind your business's own numbers.",
  },
  {
    pattern: /\b(?:avoid|evade|dodge|hide from|get around)\b.*\b(?:sars|tax|vat|paye)\b/i,
    message:
      "I can't help with that. I can explain how your tax obligations show up in these ratios, if that's useful.",
  },
];

export function classify(question: string): ClassificationResult {
  const q = question.toLowerCase();

  for (const rule of OUT_OF_SCOPE) {
    if (rule.pattern.test(question)) {
      return { disclosure: "none", cacheable: false, refusal: rule.message };
    }
  }

  // Definitional questions: no company data, and the answer is identical for
  // every tenant, so it caches globally.
  const looksDefinitional = DEFINITIONAL_PATTERNS.some((p) => p.test(question));
  const mentionsOwnership = /\b(?:my|our|we|us|i'm|i am|mine)\b/.test(q);
  if (looksDefinitional && !mentionsOwnership) {
    return { disclosure: "none", cacheable: true };
  }

  if (BROAD_PATTERNS.some((p) => p.test(question))) {
    return { disclosure: "full", cacheable: false };
  }

  // Score each pillar by term hits, weighting multi-word terms higher since
  // they're less likely to be incidental.
  const scores: Record<Pillar, number> = { profit: 0, assets: 0, financing: 0, cash: 0 };
  for (const [pillar, terms] of Object.entries(PILLAR_TERMS) as [Pillar, string[]][]) {
    for (const term of terms) {
      if (q.includes(term)) scores[pillar] += term.includes(" ") ? 2 : 1;
    }
  }

  const ranked = (Object.entries(scores) as [Pillar, number][])
    .sort((a, b) => b[1] - a[1]);
  const [topPillar, topScore] = ranked[0];
  const secondScore = ranked[1][1];

  if (topScore === 0) {
    // No signal. Cheapest useful tier — scores and firmographics only.
    return { disclosure: "summary", cacheable: false };
  }

  // Two pillars close together means the question probably spans them.
  // Cheaper to send everything once than to answer badly and get asked again.
  if (topScore > 0 && secondScore >= topScore) {
    return { disclosure: "full", cacheable: false };
  }

  return { disclosure: "focused", focusPillar: topPillar, cacheable: false };
}
