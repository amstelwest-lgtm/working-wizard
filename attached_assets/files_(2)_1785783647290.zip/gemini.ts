// MILŌN — Ask AI
// Gemini Flash client.

const MODEL = Deno.env.get("GEMINI_MODEL") ?? "gemini-2.0-flash";
const ENDPOINT =
  `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

export interface GeminiResult {
  answer: string;
  followups: string[];
  usage?: { promptTokens?: number; outputTokens?: number };
}

interface GeminiPart { text?: string }
interface GeminiCandidate {
  content?: { parts?: GeminiPart[] };
  finishReason?: string;
}
interface GeminiResponse {
  candidates?: GeminiCandidate[];
  promptFeedback?: { blockReason?: string };
  usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number };
}

export async function askGemini(
  systemPrompt: string,
  userTurn: string,
  signal?: AbortSignal,
): Promise<GeminiResult> {
  const apiKey = Deno.env.get("GEMINI_API_KEY");
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const res = await fetch(ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    signal,
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: userTurn }] }],
      generationConfig: {
        temperature: 0.3,
        topP: 0.9,
        maxOutputTokens: 700,
        responseMimeType: "application/json",
      },
    }),
  });

  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`Gemini ${res.status}: ${detail.slice(0, 300)}`);
  }

  const data = (await res.json()) as GeminiResponse;

  if (data.promptFeedback?.blockReason) {
    throw new Error(`Gemini blocked the request: ${data.promptFeedback.blockReason}`);
  }

  const text = data.candidates?.[0]?.content?.parts
    ?.map((p) => p.text ?? "")
    .join("")
    .trim();

  if (!text) throw new Error("Gemini returned an empty response");

  return {
    ...parseResult(text),
    usage: {
      promptTokens: data.usageMetadata?.promptTokenCount,
      outputTokens: data.usageMetadata?.candidatesTokenCount,
    },
  };
}

/** Tolerant parse — responseMimeType usually holds, but never bet the UI on it. */
function parseResult(text: string): { answer: string; followups: string[] } {
  const cleaned = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();

  try {
    const parsed = JSON.parse(cleaned) as { answer?: string; followups?: unknown };
    if (typeof parsed.answer === "string" && parsed.answer.trim()) {
      const followups = Array.isArray(parsed.followups)
        ? parsed.followups.filter((f): f is string => typeof f === "string").slice(0, 2)
        : [];
      return { answer: parsed.answer.trim(), followups };
    }
  } catch {
    // fall through
  }

  // Model ignored the schema. Salvage the prose rather than showing an error.
  return { answer: cleaned, followups: [] };
}
