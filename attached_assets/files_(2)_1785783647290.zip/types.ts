// MILŌN — Ask AI
// Shared types. Everything crossing the network boundary to Gemini is defined
// here, so the anonymisation surface is auditable in one file.

/** The four MILŌN pillars. */
export type Pillar = "profit" | "assets" | "financing" | "cash";

/**
 * How much company context we are willing to disclose for a given question.
 *
 *  none     — definitional / product questions. No company data leaves us at all.
 *  summary  — the four pillar scores + coarse firmographics. Cheap, ~120 tokens.
 *  focused  — summary + full ratio detail for ONE pillar. Default. ~350 tokens.
 *  full     — summary + all ratio detail. Only for explicit "review everything"
 *             questions. ~900 tokens.
 *
 * There is deliberately no tier that includes rand amounts. If you ever add one,
 * add it here and nowhere else, so this enum stays the single source of truth.
 */
export type DisclosureLevel = "none" | "summary" | "focused" | "full";

/** Direction of travel for a ratio, versus the prior period. */
export type Trend = "up_fast" | "up" | "flat" | "down" | "down_fast";

/** Health band driving the dashboard colour. */
export type Band = "strong" | "healthy" | "watch" | "critical";

/** A single ratio, stripped of anything company-identifying. */
export interface AnonRatio {
  /** Stable slug, e.g. "debtor_days". Never a client-facing label. */
  key: string;
  /** Current value, already rounded to the ratio's natural precision. */
  value: number;
  /** "days" | "x" | "%" | "ratio" — used for rendering, not identification. */
  unit: string;
  band: Band;
  /** Industry median for the same metric, if we have a benchmark. */
  industryMedian?: number;
  /** Percentile against industry peers, 0-100. */
  percentile?: number;
  trend: Trend;
  /** Value one period ago. Enables "moved from X to Y" phrasing. */
  priorValue?: number;
}

/**
 * Coarse firmographics. Every field here is bucketed on purpose — buckets are
 * what stop industry + size + age from combining into a fingerprint.
 */
export interface AnonFirmographics {
  /** Industry the client selected at onboarding. The only free-ish text field. */
  industry: string;
  /** "under_2m" | "2m_5m" | "5m_15m" | "15m_50m" | "over_50m" */
  revenueBand: string;
  /** "under_2y" | "2_5y" | "5_10y" | "over_10y" */
  ageBand: string;
  /** "pty_ltd" | "cc" | "sole_prop" | "trust" | "partnership" | "other" */
  entityType: string;
  /** "b2b" | "b2c" | "mixed" */
  customerModel: string;
  carriesInventory: boolean;
  vatRegistered: boolean;
  /** Which month of their financial year they are in, 1-12. */
  fyMonth: number;
  /** Facility types only — never limits, balances or lender names. */
  debtFacilities: string[];
  /** "under_10" | "10_25" | "25_40" | "over_40" — share of revenue, top client. */
  topCustomerConcentration?: string;
}

/** A playbook the client has already been shown, so we don't repeat ourselves. */
export interface PlaybookHistoryItem {
  key: string;
  status: "dismissed" | "in_progress" | "completed";
}

/** The complete payload that gets serialised and sent to Gemini. */
export interface AnonContext {
  disclosure: DisclosureLevel;
  firmographics?: AnonFirmographics;
  overallScore?: number;
  overallBand?: Band;
  pillarScores?: Record<Pillar, number>;
  /** Only populated for "focused" and "full". */
  ratios?: AnonRatio[];
  /** Which pillar the ratios belong to, when focused. */
  focusPillar?: Pillar;
  playbookHistory?: PlaybookHistoryItem[];
}

export interface ClassificationResult {
  disclosure: DisclosureLevel;
  focusPillar?: Pillar;
  /** True when the answer is generic enough to serve from cache across tenants. */
  cacheable: boolean;
  /** Set when we refuse to answer at all, e.g. clearly out of scope. */
  refusal?: string;
}

export interface SanitiseResult {
  clean: string;
  /** Rule names that fired. Logged as counts only, never with the matched text. */
  redactions: string[];
}

export interface AskResponse {
  answer: string;
  followups: string[];
  /** Echoed back so the UI can show what the model was and wasn't told. */
  disclosure: DisclosureLevel;
  cached: boolean;
}
