// MILŌN — Ask AI
// Builds the anonymised context payload.
//
// ⚠️  THIS IS THE ONLY FILE THAT TOUCHES THE DATABASE.
// If a field can reach Gemini, it passes through here. Keep it that way — it's
// what makes the disclosure surface reviewable in one sitting.
//
// The SELECT column lists below are written against the view in
// sql/ask_ai_setup.sql. Adapt the view, not this file, if your schema differs.

import { createClient, type SupabaseClient } from "jsr:@supabase/supabase-js@2";
import type {
  AnonContext,
  AnonFirmographics,
  AnonRatio,
  Band,
  ClassificationResult,
  Pillar,
  PlaybookHistoryItem,
  Trend,
} from "./types.ts";

// ---------------------------------------------------------------------------
// Bucketing. Coarse on purpose.
// ---------------------------------------------------------------------------

export function revenueBand(annualRevenue: number | null): string {
  if (annualRevenue == null) return "unknown";
  if (annualRevenue < 2_000_000) return "under_2m";
  if (annualRevenue < 5_000_000) return "2m_5m";
  if (annualRevenue < 15_000_000) return "5m_15m";
  if (annualRevenue < 50_000_000) return "15m_50m";
  return "over_50m";
}

export function ageBand(incorporatedOn: string | null): string {
  if (!incorporatedOn) return "unknown";
  const years = (Date.now() - new Date(incorporatedOn).getTime()) / 31_557_600_000;
  if (years < 2) return "under_2y";
  if (years < 5) return "2_5y";
  if (years < 10) return "5_10y";
  return "over_10y";
}

export function concentrationBand(pct: number | null): string | undefined {
  if (pct == null) return undefined;
  if (pct < 10) return "under_10";
  if (pct < 25) return "10_25";
  if (pct < 40) return "25_40";
  return "over_40";
}

/** Trend from current vs prior, using a 5% dead-band so noise reads as flat. */
export function trendFrom(current: number, prior: number | null, higherIsBetter: boolean): Trend {
  if (prior == null || prior === 0) return "flat";
  const delta = (current - prior) / Math.abs(prior);
  const improving = higherIsBetter ? delta > 0 : delta < 0;
  const magnitude = Math.abs(delta);
  if (magnitude < 0.05) return "flat";
  if (magnitude >= 0.20) return improving ? "up_fast" : "down_fast";
  return improving ? "up" : "down";
}

function bandFromScore(score: number): Band {
  if (score >= 80) return "strong";
  if (score >= 65) return "healthy";
  if (score >= 45) return "watch";
  return "critical";
}

// ---------------------------------------------------------------------------
// Row shapes returned by the SQL view. Adjust alongside the view.
// ---------------------------------------------------------------------------

interface ProfileRow {
  industry: string | null;
  annual_revenue: number | null;
  incorporated_on: string | null;
  entity_type: string | null;
  customer_model: string | null;
  carries_inventory: boolean | null;
  vat_registered: boolean | null;
  fy_start_month: number | null;
  debt_facilities: string[] | null;
  top_customer_pct: number | null;
}

interface ScoreRow {
  overall_score: number;
  profit_score: number;
  assets_score: number;
  financing_score: number;
  cash_score: number;
}

interface RatioRow {
  ratio_key: string;
  pillar: Pillar;
  value: number;
  unit: string;
  band: Band;
  industry_median: number | null;
  percentile: number | null;
  prior_value: number | null;
  higher_is_better: boolean;
}

interface PlaybookRow {
  playbook_key: string;
  status: "dismissed" | "in_progress" | "completed";
}

// ---------------------------------------------------------------------------

export function serviceClient(): SupabaseClient {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false } },
  );
}

/** Current month of the client's financial year, 1-12. */
function fyMonth(fyStartMonth: number | null): number {
  const start = fyStartMonth ?? 3; // SA default: March year-end is common
  const now = new Date().getUTCMonth() + 1;
  return ((now - start + 12) % 12) + 1;
}

export async function buildContext(
  db: SupabaseClient,
  companyId: string,
  classification: ClassificationResult,
): Promise<AnonContext> {
  const { disclosure, focusPillar } = classification;

  if (disclosure === "none") {
    return { disclosure };
  }

  // --- Firmographics + scores. Needed by every tier above "none". ----------
  const [profileRes, scoreRes] = await Promise.all([
    db
      .from("v_ask_ai_profile")
      .select(
        "industry, annual_revenue, incorporated_on, entity_type, customer_model, " +
          "carries_inventory, vat_registered, fy_start_month, debt_facilities, top_customer_pct",
      )
      .eq("company_id", companyId)
      .maybeSingle<ProfileRow>(),
    db
      .from("v_ask_ai_scores")
      .select("overall_score, profit_score, assets_score, financing_score, cash_score")
      .eq("company_id", companyId)
      .maybeSingle<ScoreRow>(),
  ]);

  if (profileRes.error) throw profileRes.error;
  if (scoreRes.error) throw scoreRes.error;

  const p = profileRes.data;
  const s = scoreRes.data;

  const firmographics: AnonFirmographics | undefined = p
    ? {
      industry: p.industry ?? "unspecified",
      revenueBand: revenueBand(p.annual_revenue),
      ageBand: ageBand(p.incorporated_on),
      entityType: p.entity_type ?? "unknown",
      customerModel: p.customer_model ?? "unknown",
      carriesInventory: p.carries_inventory ?? false,
      vatRegistered: p.vat_registered ?? false,
      fyMonth: fyMonth(p.fy_start_month),
      debtFacilities: p.debt_facilities ?? [],
      topCustomerConcentration: concentrationBand(p.top_customer_pct),
    }
    : undefined;

  const context: AnonContext = {
    disclosure,
    firmographics,
    overallScore: s?.overall_score,
    overallBand: s ? bandFromScore(s.overall_score) : undefined,
    pillarScores: s
      ? {
        profit: s.profit_score,
        assets: s.assets_score,
        financing: s.financing_score,
        cash: s.cash_score,
      }
      : undefined,
  };

  if (disclosure === "summary") return context;

  // --- Ratio detail ---------------------------------------------------------
  let query = db
    .from("v_ask_ai_ratios")
    .select(
      "ratio_key, pillar, value, unit, band, industry_median, percentile, prior_value, higher_is_better",
    )
    .eq("company_id", companyId);

  if (disclosure === "focused" && focusPillar) {
    query = query.eq("pillar", focusPillar);
    context.focusPillar = focusPillar;
  }

  const ratioRes = await query.returns<RatioRow[]>();
  if (ratioRes.error) throw ratioRes.error;

  let rows = ratioRes.data ?? [];

  // On "full", 31 ratios is more than the answer needs and more than the
  // budget wants. Send the ones that are actually saying something: anything
  // off-band, then anything moving fast, then fill to 14 with the rest.
  if (disclosure === "full" && rows.length > 14) {
    const priority = (r: RatioRow) => {
      if (r.band === "critical") return 0;
      if (r.band === "watch") return 1;
      const t = trendFrom(r.value, r.prior_value, r.higher_is_better);
      if (t === "down_fast" || t === "up_fast") return 2;
      return 3;
    };
    rows = [...rows].sort((a, b) => priority(a) - priority(b)).slice(0, 14);
  }

  context.ratios = rows.map((r): AnonRatio => ({
    key: r.ratio_key,
    value: round(r.value),
    unit: r.unit,
    band: r.band,
    industryMedian: r.industry_median != null ? round(r.industry_median) : undefined,
    percentile: r.percentile ?? undefined,
    trend: trendFrom(r.value, r.prior_value, r.higher_is_better),
    priorValue: r.prior_value != null ? round(r.prior_value) : undefined,
  }));

  // --- Playbook history: stops the model re-pitching rejected advice --------
  const pbRes = await db
    .from("v_ask_ai_playbook_history")
    .select("playbook_key, status")
    .eq("company_id", companyId)
    .limit(12)
    .returns<PlaybookRow[]>();

  if (!pbRes.error && pbRes.data?.length) {
    context.playbookHistory = pbRes.data.map((r): PlaybookHistoryItem => ({
      key: r.playbook_key,
      status: r.status,
    }));
  }

  return context;
}

function round(n: number): number {
  return Math.abs(n) >= 100 ? Math.round(n) : Math.round(n * 100) / 100;
}
