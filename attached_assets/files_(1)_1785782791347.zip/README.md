# Financial statement PDF → structured data (Gemini)

Drop-in module that takes a financial-statement PDF, sends it to Gemini, and
returns clean structured JSON your ratio engine can consume — with a validation
layer and a human review step so bad numbers never reach the database.

## Files

- `lib/financialSchema.ts` — the JSON schema Gemini must fill + matching TS types
- `lib/extractFinancials.ts` — the Gemini call (server-side only)
- `lib/validateFinancials.ts` — deterministic checks (does the balance sheet balance, etc.)
- `server.ts` — Express server exposing `POST /api/extract-financials` (easiest to run)
- `components/UploadFinancials.tsx` — React upload + editable review UI
- `.env.example` — where the API key goes

## Which model

Uses **`gemini-3.5-flash-lite`** — the cheapest current-generation model that
still accepts PDFs natively and supports structured output. To connect it you
only need an API key; the model name is already set in `lib/extractFinancials.ts`.
For messier scanned PDFs you can change one line to `gemini-3.6-flash`.

## Setup (5 steps)

1. Get a key at https://aistudio.google.com/apikey
2. Add it as a secret named `GEMINI_API_KEY` (Replit: Tools → Secrets)
3. Install deps:
   ```
   npm install @google/genai express cors
   npm install -D typescript tsx @types/express @types/cors
   ```
4. Run the server:
   ```
   npx tsx server.ts
   ```
5. Point the React component's `endpoint` at that URL and drop it into a page.

## Wiring the result into your app

`onConfirm(result)` fires only after a human has reviewed and (if needed)
corrected the figures. That's where you persist to Supabase / feed the ratios:

```tsx
<UploadFinancials onConfirm={(result) => {
  // result is the corrected ExtractionResult
  saveToSupabase(result);
  computeRatios(result.current_period.figures);
}} />
```

## Important

- The API key must stay server-side. Never call Gemini from the browser.
- `autoImportSafe: false` in the API response means an arithmetic check failed —
  require a human to confirm before importing.
- `units` tells you the scale (actual / thousands / millions). The numbers are
  NOT rescaled for you — handle that on import so nothing is silently multiplied.
